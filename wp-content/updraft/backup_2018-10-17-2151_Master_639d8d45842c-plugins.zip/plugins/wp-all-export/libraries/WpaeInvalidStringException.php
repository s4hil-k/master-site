<?php

class WpaeInvalidStringException extends Exception
{

}