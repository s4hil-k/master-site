<?php

class WpaeTooMuchRecursionException extends Exception
{

}