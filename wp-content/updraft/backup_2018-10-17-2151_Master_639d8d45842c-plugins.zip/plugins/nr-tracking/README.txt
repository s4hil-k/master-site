=== NR Tracking Essentials ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://www.linkedin.com/in/s4hilk/
Tags: comments, spam
Requires at least: 3.0.1
Tested up to: 4.8
Stable tag: 4.8
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Use This Plugin to add Google Tag manager and Bing validation code to your site.

== Description ==

Use This Plugin to add Google Tag manager and Bing validation code to your site. You will have to add `<?php do_action('nr_noscript_gtm') ?>` where you want the noscript version of GTM (Usually after body opening tag).


*   "Contributors" is a comma separated list of wp.org/wp-plugins.org usernames
*   "Tags" is a comma separated list of tags that apply to the plugin
*   "Requires at least" is the lowest version that the plugin will work on
*   "Tested up to" is the highest version that you've *successfully used to test the plugin*. Note that it might work on
higher versions... this is just the highest one you've verified.
*   Stable tag should indicate the Subversion "tag" of the latest stable version, or "trunk," if you use `/trunk/` for
stable.


== Installation ==

- Upload the nr-tracking.zip to your site.
- You can find the plugin settings under Settings.

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.


== Screenshots ==



== Changelog ==

= 1.0 =
* Added the user instructions in readme file. 

= 0.5 =
* Added Bing compatibility

== Upgrade Notice ==

= 1.0 =
No Upgrades Yet
