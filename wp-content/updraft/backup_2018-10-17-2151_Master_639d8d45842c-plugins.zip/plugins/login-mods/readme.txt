=== Log In Message ===
Contributors: mohanjith
Tags: login message, password reset
Tested up to: 3.3.1
Stable tag: 1.0.2
Requires at least: 3.0

Add custom log in messages

== Description ==

Add custom log in messages to wp-login.php . You can also disable password reset
and display a custom message instead.

== Changelog ==

= 1.0.2 =
WordPress 3.8 compatibility

= 1.0.1 =
By popular demand now works with WordPress and BuddyPress

= 1.0.0 =
Initial Release

== Installation ==

Use automatic installer or copy to plugins and network activate


369791-1507925506-ai